# ===============================
# Personal Expense Tracker
# Input-based & EOF Safe Version
# ===============================

expenses = []
monthly_budget = 0


def safe_input(message):
    """Takes input safely even if input is not available"""
    try:
        return input(message)
    except EOFError:
        print("\nInput not available. Exiting safely.")
        exit()


def set_budget():
    global monthly_budget
    try:
        monthly_budget = float(safe_input("Enter monthly budget: ₹"))
        print("Budget set successfully!\n")
    except ValueError:
        print("Invalid budget amount.\n")


def add_expense():
    try:
        amount = float(safe_input("Enter expense amount: ₹"))
        category = safe_input("Enter category (Food/Travel/Fun): ").capitalize()
        note = safe_input("Enter note: ")

        expenses.append({
            "amount": amount,
            "category": category,
            "note": note
        })

        print("Expense added successfully!\n")
    except ValueError:
        print("Invalid amount entered.\n")


def view_expenses():
    if not expenses:
        print("No expenses recorded.\n")
        return

    print("\n--- Expenses ---")
    for i, e in enumerate(expenses, start=1):
        print(f"{i}. ₹{e['amount']} | {e['category']} | {e['note']}")
    print()


def total_expense():
    total = sum(e["amount"] for e in expenses)
    print(f"Total Expense: ₹{total}")

    if monthly_budget > 0 and total > monthly_budget:
        print("⚠ Budget exceeded!")
    print()


def menu():
    print("====== Expense Tracker ======")
    print("1. Set Monthly Budget")
    print("2. Add Expense")
    print("3. View Expenses")
    print("4. View Total Expense")
    print("5. Exit")


# -------- Program Loop --------
while True:
    menu()
    choice = safe_input("Enter your choice (1-5): ")

    if choice == "1":
        set_budget()
    elif choice == "2":
        add_expense()
    elif choice == "3":
        view_expenses()
    elif choice == "4":
        total_expense()
    elif choice == "5":
        print("Thank you for using Expense Tracker 😊")
        break
    else:
        print("Invalid choice. Try again.\n")